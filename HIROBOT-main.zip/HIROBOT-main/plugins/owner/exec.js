import { format } from 'util'
import { fileURLToPath } from 'url'
import { dirname } from 'path'
import { createRequire } from 'module'
import connection from '../../lib/utils/connection.js'
import cp, { exec as _exec } from 'child_process'
import { promisify } from 'util'
import Helper from '../../lib/utils/helper.js'

const __dirname = dirname(fileURLToPath(import.meta.url))
const require = createRequire(__dirname)
const exec = promisify(_exec).bind(cp)

let handler = async (m, _2) => {
  let { conn, usedPrefix, noPrefix, args, groupMetadata, command, text } = _2
  if (m.sender == conn.user.jid && (m.id).startsWith("3EB0")) return

  if (/^[$] /.test(usedPrefix + noPrefix) || (command && /^[$]$/.test(command))) {
    let o
    try {
      o = await exec(command.trimStart() + ' ' + text.trimEnd())
    } catch (e) {
      o = e
    } finally {
      let { stdout, stderr } = o
      if (stdout && stdout.trim()) conn.sendMessage(m.chat, { text: stdout }, { quoted: m })
      if (stderr && stderr.trim()) conn.sendMessage(m.chat, { text: stderr }, { quoted: m })
    }
    return
  }

  let _return
  let _syntax = ''
  let _text = (/^<</.test(usedPrefix) ? 'return ' : '') + noPrefix
  let old = m.exp * 1
  try {
    let i = 15
    let f = {
      exports: {}
    }
    let evalExec = new (async () => { }).constructor('print', 'm', 'handler', 'require', 'conn', 'db', 'store', 'connection', 'Array', 'process', 'args', 'groupMetadata', 'module', 'exports', 'argument', _text)
    _return = await evalExec.call(conn, (...args) => {
      if (--i < 1) return
      console.log(...args)
      return conn.reply(m.chat, format(...args), m)
    }, m, handler, require, conn, db, connection.store, connection, CustomArray, process, args, groupMetadata, f, f.exports, [conn, _2])
  } catch (e) {
    let err = Helper.checkSyntax(_text, 'Execution Function', {
      allowReturnOutsideFunction: true,
      allowAwaitOutsideFunction: true,
      sourceType: 'module'
    })
    if (err) _syntax = '```' + err + '```\n\n'
    _return = e
  } finally {
    conn.reply(m.chat, _syntax + format(_return), m)
    m.exp = old
  }
}

handler.help = ['< ', '<<', '$ ']
handler.tags = ['advanced']
handler.customPrefix = /^(<?< |[$] )/
handler.command = /(?:)/i
handler.rowner = true
handler.ai = { risk: 'low', description: "run javascript code or shell command (owner only)" }

export default handler

class CustomArray extends Array {
  constructor(...args) {
    if (typeof args[0] == 'number') return super(Math.min(args[0], 10000))
    else return super(...args)
  }
}
